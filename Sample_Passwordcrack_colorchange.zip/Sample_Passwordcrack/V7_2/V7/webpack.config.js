var path = require('path');
var ExtractTextPlugin = require('extract-text-webpack-plugin');

var inlineAssets = process.env.WEBPACK_INLINE_ASSETS ? true : false;
var dev = process.env.NODE_ENV === 'development' ? true : false;

module.exports = function() {
	return {
		context: path.resolve(__dirname, 'src'),
		entry: path.resolve(__dirname, 'src', 'index.js'),
		output: {
			path: path.resolve(__dirname, 'dist'),
			filename: 'index.js',
		},
		module: {
			loaders: [
				{
					test: /\.js$/,
					loader: 'babel-loader',
					query: {
						presets: [ 'es2015-webpack' ],
					},
					exclude: /node_modules/,
				},
				{
					test: /\.css$/,
					loader: 'style-loader!css-loader?-autoprefixer',
				},
				{
					test: /\.(png|jpg)$/,
					loader: inlineAssets ? 'url-loader?limit=1000000' : 'file-loader?name=[path][name].[ext]'
				},
				{
					test: /\.html$/,
					loader: 'file-loader?name=[name].[ext]'
				},
				{
					test: /\.(svg|woff)$/,
					loader: 'url-loader?limit=100000'
				}
			]
		},
		devtool: dev ? 'inline-source-map' : false,
	};
}