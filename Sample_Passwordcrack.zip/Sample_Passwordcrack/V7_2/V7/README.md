# How to customize
Use src/index.html and change source files in src/
Images are in src/img, stylesheets in src/style, fonts in src/fonts and
credential settings can be found in src/settings.js

# How to distribute

## Easy
Just copy and rename the src directory

## Minify
* install [node.js](https://nodejs.org/)
* run `npm install`
* run `npm install -g webpack webpack-dev-server`
* run `npm run command` where command is one of
	* `build-dev` build with sourcemaps
	* `build-prod` build without sourcemaps and minify source
	* `build-serv` start development server
	* `build-min` build minified production bundle constisting of one html file
* files will be in `dist`