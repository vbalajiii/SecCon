/*! @preserve Change settings here !*/
window.credentials = {
	'Desmond': [ 'Password1', 'Password2', 'Password3', 'Password4', 'Password5' ],
};
window.initialUser = 'Desmond';
/*! @preserve -------------------- !*/