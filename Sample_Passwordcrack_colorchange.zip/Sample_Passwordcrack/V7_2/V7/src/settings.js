/*! @preserve Change settings here !*/
window.credentials = {
	'Peter Pan': [ '19640512', 'Katharina20', 'FlyingDutchman', 'BayernMunich', 'CastorPollux' ],
};
window.initialUser = 'Peter Pan';
/*! @preserve -------------------- !*/