﻿if (typeof require !== 'undefined') {
	require('./index.html');
	require('./style/main.css')
	require('./settings.js');
}

window.onload = init;

var xmlDoc;
var xmlloaded = false;
var totalNumber = 5;
var totalCorrect = 0;
var userName = "";
var passwords = [""];

var usedCredentials = {};

var countdownInterval;
var originalCountdown = 60 * 5; // 60 seconds * 5 = 5 minutes
var countdown = originalCountdown;
var countdownStarted = false;
function startCountdown() {
	if (countdownStarted) return;
	countdownStarted = true;
	countdownInterval = setInterval(advanceCountdown, 1000);
}

function advanceCountdown() {
	countdown--;
	var minutes = Math.floor(countdown / 60);
	var seconds = Math.floor(countdown % 60);
	if (seconds < 10) {
		seconds = "0" + seconds;
	}
	document.getElementById('countdown').innerHTML = minutes + ':' + seconds;
	if (countdown <= 0) {
		clearInterval(countdownInterval);
		setTimeout(function() {
			finish({ won: false })
		}, 500);
	}
}

function finish(options) {
	var time = originalCountdown - countdown;
	var minutes = Math.floor(time / 60);
	var seconds = Math.floor(time % 60);
	var text = "Congratulations!";
	if (options.won) {
		text = text + " You have won!";
	}
	text = text + "\nCorrect Guesses: " + totalCorrect +" out of "+ totalNumber + 
				".\nTotal Time: " + minutes + " minutes & " + seconds + " seconds."
	alert (text);
}

function init() {
	localStorage.clear();
	var button = document.getElementById("buttonHinzufuegen");
	button.onclick = buttonClickHandler;
	document.getElementById("userInput").value = initialUser;
	document.getElementById("passwordInput").focus();
	document.getElementById("userInput").oninput = startCountdown;
	document.getElementById("passwordInput").oninput = startCountdown;
}

function buttonClickHandler(e) {
	var userInput = document.getElementById('userInput');
	var textInput = document.getElementById("passwordInput");
	var user = userInput.value;
	var password = textInput.value;
	textInput.value = ""; //Lösche Passwort aus Feld
	textInput.focus();
	//alert("Füge " + Password + " hinzu");

	if (password == "") {
		alert("Please enter a password!");
	}
	else {
		var treffer = passwordTest (user, password);
		// alert("Füge " + Password + " hinzu");
		var li = document.createElement("li");
		li.innerHTML = password;
		if (treffer === 'wrong') {
			li.className = li.className + " falsePassword"; //Wenn kein treffer, dann füge css-klasse hinzu
			
			var ul = document.getElementById("passwordlistwrong");
			ul.appendChild(li);
			var objDiv = document.getElementById("passwrong");
			objDiv.scrollTop = objDiv.scrollHeight;
		} else if(treffer === 'wrongused') {
			alert('You already tried this password before.')
		} else if(treffer === 'used') {
			alert('This password is correct but you already used it before.')
		} else if(treffer === 'correct') {
			totalCorrect++;
			var ul = document.getElementById("passwordlistright");
			ul.appendChild(li);
			var objDiv = document.getElementById("passright");
			objDiv.scrollTop = objDiv.scrollHeight;
			if (totalCorrect == totalNumber)
			{
				finish({ won: true });
			}
		}
	}
}

function passwordTest (user, password) {	
	var treffer = 'wrong';
	if (credentials && credentials[user] && credentials[user].indexOf(password) !== -1) {
		treffer = 'correct';
	}
	if (usedCredentials && usedCredentials[user] && usedCredentials[user].indexOf(password) !== -1) {
		if (treffer === 'correct') {
			treffer = 'used';
		} else {
			treffer = 'wrongused';
		}
	} else {
		usedCredentials[user] = usedCredentials[user] || [];
		usedCredentials[user].push(password);
	}
	return treffer;
}

function trimAll(sString) 
{ 
	while (sString.substring(0,1) == ' ') 
	{ 
		sString = sString.substring(1, sString.length); 
	} 
	while (sString.substring(sString.length-1, sString.length) == ' ') 
	{ 
		sString = sString.substring(0,sString.length-1); 
	}
	// alert ("String: " + sString + " Stringlänge: " + sString.length); 
	return sString; 
}